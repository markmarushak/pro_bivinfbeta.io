<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">

            <div class="col-sm-12">
                <header>
                    <h3>Контекст для групп</h3>
                </header>
            </div>

            <div class="col-sm-12">

                <div class="main">
                    <form action="#" id="add_content">

                        <div class="row">

                            <div class="form-group col-sm-3">
                                <label>
                                <span>
                                    выберите группу для заполнения
                                </span>
                                    <select name="group_id" class="form-control group_id" required>
                                        <option value="-">выберите</option>
                                        <?php $__currentLoopData = $groups->where('main_id',0)->get()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e($group['name']); ?>">
                                                <?php $__currentLoopData = $groups->getparent($group['id']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>

                            <div class="form-group col-sm-3">
                                <label>
                                    <span>
                                        стоимость услуги
                                    </span>
                                    <input type="number" name="price" class="form-control price" required>
                                </label>
                            </div>

                            <div class="form-group col-sm-3">
                                <label>
                                    <span>
                                        сроки выполнения
                                    </span>
                                    <input type="text" name="time" class="form-control time" required>
                                </label>
                            </div>

                            <div class="form-group col-sm-3">
                                <label for="">
                                    <span>проверьте и сохраните информацию</span>
                                    <button class="btn btn-success btn-block">сохранить</button>
                                </label>
                            </div>

                            <div class="form-group col-sm-12">
                                <textarea name="text" id="" cols="30" rows="10" class="form-control text"></textarea>
                            </div>

                        </div>

                    </form>
                </div>

            </div>

            <hr>

            <div class="col-sm-12">

                <div class="notification">

                    <form action="#" id="add_section">

                        <div class="row">

                            <div class="form-group col-sm-4">

                                <label>
                                    <span>Введите дополнительную информацию:</span>
                                    <select name="section_id" id="dop" class="form-control section_id">
                                        <option value="-">Выберите секцию</option>
                                        <option value="1">Верхняя секция</option>
                                        <option value="2">Средня секция</option>
                                        <option value="3">Нижняя секция</option>
                                    </select>
                                </label>
                            </div>

                            <div class="form-group col-sm-4">
                                <label>
                                    <span>проверьте и сохраните информацию</span>
                                    <button class="btn btn-success btn-block">сохранить</button>
                                </label>
                            </div>


                            <div class="form-group col-sm-12">
                                <textarea name="text" cols="30" rows="10" class="form-control text"></textarea>
                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/admin_main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>