<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container">
            <div class="row">

                <div class="col-sm-4">
                    <nav class="menu">
                        <ul>
                            <?php $__currentLoopData = $menu->where('main_id',0)->get()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <button class="drop"><?php echo e($item['name']); ?></button>
                                    <div>
                                        <ul>
                                            <?php $__currentLoopData = $menu->getParent($item['id']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="#" data-id="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </nav>
                </div>

                <div class="col-sm-4">
                    <div id="content" class="text-center">
                        <div class="name"></div>
                        <div class="price"></div>
                        <div class="time"></div>
                        <div class="text"></div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="attention">

                        <section id="1">
                            <p><?php if(!empty($section[0]['text'])): ?><?php echo e($section[0]['text']); ?> <?php endif; ?></p>
                        </section>

                        <section>
                            <p><?php if(!empty($section[1]['text'])): ?><?php echo e($section[1]['text']); ?> <?php endif; ?></p>
                        </section>

                        <section>
                            <p><?php if(!empty($section[2]['text'])): ?><?php echo e($section[2]['text']); ?> <?php endif; ?></p>
                        </section>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>